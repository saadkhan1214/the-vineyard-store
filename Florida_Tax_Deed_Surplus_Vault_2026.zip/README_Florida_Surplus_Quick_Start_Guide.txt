========================================================================================
FLORIDA TAX DEED SURPLUS ARBITRAGE // QUICK-START OPERATIONAL GUIDE (2026 EDITION)
========================================================================================

Welcome to the 2026 Florida County Tax Deed Surplus Directory.

WHAT IS THIS ASSET?
When a property is sold at a Florida tax deed auction for more than the back taxes owed, 
the excess money does NOT go to the government. By Florida Statute § 197.582, excess 
proceeds belong to the former property owner or their legal heirs.

This master directory contains 400 certified, non-demo excess proceeds records currently 
held in county treasury escrow across Florida, representing over $7,526,274.08 USD in 
unclaimed capital.

HOW TO OPERATE THIS DATA FOR 30% CONTINGENCY RECOVERY:
1. Open the CSV file in Excel, Google Sheets, or Numbers.
2. Filter for high-ticket claims (e.g. claims above $30,000 where your 30% fee is $9,000+).
   - Top Lead: Christopher B. Warren (Marion County) - $131,263.49 Surplus ($39,379.05 Fee).
   - Tammie Lee Hill (Marion County) - $94,737.79 Surplus ($28,421.34 Fee).
   - Estate of Charles L. Barr - $77,497.63 Surplus ($23,249.29 Fee).
3. Skip-trace the owner or estate heirs using public records, TruePeopleSearch, FastPeopleSearch, 
   or county probate court dockets.
4. Use the included Florida_Statute_197_582_Contingency_Claim_Petition.txt contract.
   The former owner signs the 30% contingency agreement.
5. Submit the claim packet to the County Clerk of Court & Comptroller.
   The county directly cuts TWO checks:
   - 70% direct to the former owner.
   - 30% direct to YOU (The Recovery Agent).

TOTAL LEGAL AUTHORITY:
Governed by Florida Statute § 197.582 and Florida Administrative Code Rule 12D-13.065.
Zero upfront capital required. 100% success-based contingency.
========================================================================================